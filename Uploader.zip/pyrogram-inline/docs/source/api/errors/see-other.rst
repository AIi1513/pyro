303 - SeeOther
--------------

.. csv-table::
    :file: ../../../../compiler/errors/source/303_SEE_OTHER.tsv
    :delim: tab
    :header-rows: 1